package bankmanagementsystem;

public class Account {

    private String type;
    private String branchCode;
    private double balance;
    private String accountNum;
    private String password;

    public Account() {
    }

    public Account(String type, String branchCode, double balance, String accountNum, String password) {
        this.type = type;
        this.branchCode = branchCode;
        this.balance = balance;
        this.accountNum = accountNum;
        this.password = password;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
