package bankmanagementsystem;

public class BankManagementSystem {

    public static void main(String[] args) {
        AdminDashboard admin = new AdminDashboard();
        admin.setVisible(true);
    }
}
